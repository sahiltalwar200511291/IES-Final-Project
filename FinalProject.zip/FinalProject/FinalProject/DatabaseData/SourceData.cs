﻿using FinalProject.Authorizations;
using FinalProject.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

// dotnet aspnet-codegenerator razorpage -m Contact -dc ApplicationDbContext -outDir Pages\Contacts --referenceScriptLibraries
namespace FinalProject.Data
{
    public static class SourceData
    {
#pragma warning disable CS8602 // Dereference of a possibly null reference.
        #region snippet_Initialize
        public static async Task Initialize(IServiceProvider serviceProvider, string AdminManagerPW)
        {
            using (var context = new ApplicationDbContext(
                serviceProvider.GetRequiredService<DbContextOptions<ApplicationDbContext>>()))
            {
                // For sample purposes seed both with the same password.
                // Password is set with the following:
                // dotnet user-secrets set SeedUserPW <pw>
                // The admin user can do anything

                var adminID = await EnsureUser(serviceProvider, AdminManagerPW, "admin@mymail.com");
                await EnsureRole(serviceProvider, adminID, Constants.ContactAdministratorsRole);

                // allowed user can create and edit contacts that they create
                var managerID = await EnsureUser(serviceProvider, AdminManagerPW, "manager@mymail.com");
                await EnsureRole(serviceProvider, managerID, Constants.ContactManagersRole);

                SeedDB(context, adminID);
            }
        }

        private static async Task<string> EnsureUser(IServiceProvider serviceProvider,
                                                    string AdminManagerPW, string UserName)
        {
            var userManager = serviceProvider.GetService<UserManager<IdentityUser>>();

            var user = await userManager.FindByNameAsync(UserName);
            if (user == null)
            {
                user = new IdentityUser
                {
                    UserName = UserName,
                    EmailConfirmed = true
                };
                await userManager.CreateAsync(user, AdminManagerPW);
            }

            if (user == null)
            {
                throw new Exception("The password is probably not strong enough!");
            }

            return user.Id;
        }

        private static async Task<IdentityResult> EnsureRole(IServiceProvider serviceProvider,
                                                                      string uid, string role)
        {
            var roleManager = serviceProvider.GetService<RoleManager<IdentityRole>>();

            if (roleManager == null)
            {
                throw new Exception("roleManager null");
            }

            IdentityResult IR;
            if (!await roleManager.RoleExistsAsync(role))
            {
                IR = await roleManager.CreateAsync(new IdentityRole(role));
            }

            var userManager = serviceProvider.GetService<UserManager<IdentityUser>>();

            //if (userManager == null)
            //{
            //    throw new Exception("userManager is null");
            //}

            var user = await userManager.FindByIdAsync(uid);

            if (user == null)
            {
                throw new Exception("The AdminManagerPW password was probably not strong enough!");
            }

            IR = await userManager.AddToRoleAsync(user, role);

            return IR;
        }
        #endregion
        #region snippet1
        public static void SeedDB(ApplicationDbContext context, string adminID)
        {
            if (context.Contact.Any())
            {
                return;   // DB has been seeded
            }

            context.Contact.AddRange(
            #region snippet_Contact
                new Contact
                {
                    Name = "Sahil Talwar",
                    Address = "1234 Main St",
                    City = "Batala",
                    State = "PUN",
                    Zip = "143505",
                    Email = "SahilTalwar@mymail.com",
                    Status = ContactStatus.Approved,
                    OwnerID = adminID
                },
            #endregion
            #endregion
                 new Contact
                {
                    Name = "Lovkesh Handa",
                    Address = "1234 Main St",
                    City = "Amritsar",
                    State = "PUN",
                    Zip = "143501",
                    Email = "Lovkesh@mymail.com",
                    Status = ContactStatus.Approved,
                    OwnerID = adminID
                },
                new Contact
                {
                    Name = "Ankush Bansal",
                    Address = "5678 1st Ave W",
                    City = "Ludhiana",
                    State = "PUN",
                    Zip = "143502",
                    Email = "Ankush@mymail.com",
                    Status = ContactStatus.Submitted,
                    OwnerID = adminID
                },
             new Contact
             {
                 Name = "Ridhima Mahajan",
                 Address = "9012 State st",
                 City = "Dasuya",
                 State = "PUN",
                 Zip = "143203",
                 Email = "Ridhima@mymail.com",
                 Status = ContactStatus.Rejected,
                 OwnerID = adminID
             },
             new Contact
             {
                 Name = "Sumira Chawla",
                 Address = "3456 Maple St",
                 City = "Amritsar",
                 State = "PUN",
                 Zip = "143501",
                 Email = "Sumira@mymail.com",
                 Status = ContactStatus.Submitted,
                 OwnerID = adminID
             },
             new Contact
             {
                 Name = "Rahul Chaudhary",
                 Address = "7890 2nd Ave E",
                 City = "Delhi",
                 State = "DEL",
                 Zip = "122001",
                 Email = "Rahul@mymail.com",
                 OwnerID = adminID
             }
             );
            context.SaveChanges();
        }
    }
}
#pragma warning restore CS8602 // Dereference of a possibly null reference.
